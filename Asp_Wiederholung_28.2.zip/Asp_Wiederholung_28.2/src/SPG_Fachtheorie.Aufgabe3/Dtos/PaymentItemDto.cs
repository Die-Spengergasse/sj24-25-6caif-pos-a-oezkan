﻿namespace SPG_Fachtheorie.Aufgabe3.Dtos
{
    public record PaymentItemDto(string articleName, int amount, decimal price);
}
