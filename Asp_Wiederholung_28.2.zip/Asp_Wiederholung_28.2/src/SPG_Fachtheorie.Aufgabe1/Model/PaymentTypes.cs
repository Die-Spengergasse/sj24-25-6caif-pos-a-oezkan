﻿namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public enum PaymentType
    {  
        Cash,
        Maestro,
        CreditCard
    }
}